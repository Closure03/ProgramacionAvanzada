Jhonnier Peñaralta, Santiago Garzon
